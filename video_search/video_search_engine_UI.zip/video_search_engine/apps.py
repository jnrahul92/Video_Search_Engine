from django.apps import AppConfig


class VideoSearchEngineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'video_search_engine'
